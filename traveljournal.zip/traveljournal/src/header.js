import React from "react";
import { FaEarthAmericas } from "react-icons/fa6";
export default function header() {
  return (
    <div className="nav">
      <FaEarthAmericas style={{ paddingRight: "5px" }} />
      <p>My Travel Journal</p>
    </div>
  );
}
