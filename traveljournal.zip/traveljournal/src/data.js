const travelData = [
  {
    title: "Cultural Exploration in Kyoto",
    location: "Kyoto, Japan",
    googleMapsUrl: "https://www.google.com/maps?q=Kyoto",
    startDate: "2024-03-15",
    endDate: "2024-03-22",
    description:
      "Immersing in the rich cultural heritage of Kyoto, exploring historic temples, and savoring traditional Japanese cuisine.",
    imageUrl:
      "https://www.google.com/url?sa=i&url=https%3A%2F%2Fboutiquejapan.com%2Fkyoto-guide%2F&psig=AOvVaw0Ap0y6SmzPxcS6jNylpaAX&ust=1710254265426000&source=images&cd=vfe&opi=89978449&ved=0CBMQjRxqFwoTCPj0xOG37IQDFQAAAAAdAAAAABAE",
  },
  {
    title: "Skiing Adventure in the Swiss Alps",
    location: "Zermatt, Switzerland",
    googleMapsUrl: "https://www.google.com/maps?q=Zermatt",
    startDate: "2024-02-10",
    endDate: "2024-02-18",
    description:
      "Thrilling ski adventures in the breathtaking Swiss Alps, enjoying picturesque snow-covered landscapes.",
    imageUrl: "https://example.com/zermatt.jpg",
  },
  {
    title: "City Lights in New York",
    location: "New York City, USA",
    googleMapsUrl: "https://www.google.com/maps?q=New+York",
    startDate: "2024-05-05",
    endDate: "2024-05-12",
    description:
      "Exploring the vibrant streets of New York City, visiting iconic landmarks, and experiencing the city's energy.",
    imageUrl: "https://example.com/nyc.jpg",
  },
  {
    title: "Serene Retreat in Santorini",
    location: "Santorini, Greece",
    googleMapsUrl: "https://www.google.com/maps?q=Santorini",
    startDate: "2024-09-08",
    endDate: "2024-09-15",
    description:
      "Relaxing on the beautiful beaches of Santorini, admiring the stunning sunsets, and indulging in Greek hospitality.",
    imageUrl: "https://example.com/santorini.jpg",
  },
  {
    title: "Jungle Expedition in Costa Rica",
    location: "Monteverde, Costa Rica",
    googleMapsUrl: "https://www.google.com/maps?q=Monteverde",
    startDate: "2024-07-20",
    endDate: "2024-07-28",
    description:
      "Venturing into the lush jungles of Costa Rica, discovering exotic wildlife, and experiencing eco-friendly adventures.",
    imageUrl: "https://example.com/monteverde.jpg",
  },
  {
    title: "Historical Marvels in Rome",
    location: "Rome, Italy",
    googleMapsUrl: "https://www.google.com/maps?q=Rome",
    startDate: "2024-04-12",
    endDate: "2024-04-20",
    description:
      "Exploring the ancient wonders of Rome, visiting the Colosseum, and savoring authentic Italian cuisine.",
    imageUrl: "https://example.com/rome.jpg",
  },
];

export default travelData;
