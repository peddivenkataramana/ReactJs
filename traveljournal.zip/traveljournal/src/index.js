import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import Head from "./header.js";
import Card from "./cards.js";
import Data from "./data.js";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <div className="App">
    <Head />
    {Data.map((entry, index) => (
      <Card entry={entry} index={index}></Card>
    ))}
  </div>
);
