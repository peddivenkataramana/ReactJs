import React from "react";
import { FaLocationDot } from "react-icons/fa6";
export default function cards({ entry }) {
  return (
    <div className="card">
      <img src="entry.imgUrl" />
      <div className="left">
        <p style={{ fontSize: "20px" }}>
          <FaLocationDot style={{ fontSize: "10px", padding: "3px" }} />
          {entry.location}
          <a style={{ fontSize: "10px", padding: "5px" }}>
            View on Google Maps
          </a>
        </p>
        <h2>{entry.title}</h2>
        <p>
          {entry.startDate} - {entry.endDate}
        </p>
        <p>{entry.description}</p>
      </div>
    </div>
  );
}
