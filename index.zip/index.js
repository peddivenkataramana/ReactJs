import React, { useState } from "react";
import ReactDOM from "react-dom";

const App = () => {
  const [FirstName, setFrst] = useState("");
  const [LastName, setLast] = useState("");

  const submitt = (e) => {
    e.preventDefault();
    console.log("First Name: ", FirstName);
    console.log("Last Name: ", LastName);
  };
  return (
    <div>
      <form onSubmit={submitt}>
        <h2>Form</h2>
        <p>FirstName:</p>
        <input type="text" onChange={(e) => setFrst(e.target.value)}></input>
        <br />
        <p>LastName:</p>
        <input type="text" onChange={(e) => setLast(e.target.value)}></input>

        <button type="submit">submit</button>
      </form>
      <p>FirstName:{FirstName}</p>
      <p>LastName:{LastName}</p>
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
