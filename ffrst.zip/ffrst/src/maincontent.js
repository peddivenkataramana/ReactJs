import React from "react";

export default function Mainn() {
  return (
    <div className="mainn">
      <h1>Fun facts about React</h1>
      <ul>
        <li>Was first release in 2013</li>
        <li>Was originally created by Jordan Walke</li>
        <li>Is maintained by facebook</li>
      </ul>
    </div>
  );
}
