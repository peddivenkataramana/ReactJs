import React, { useState } from "react";
import ReactDOM from "react-dom";

function ContactList({ contacts, deleteContact }) {
  return (
    <div>
      <h2>Contact List</h2>
      <ul>
        {contacts.map((contact, index) => (
          <li key={index}>
            <strong>Name:</strong> {contact.name}
            <br />
            <strong>Email:</strong> {contact.email}
            <br />
            <strong>Phone:</strong> {contact.phno}
            <br />
            <button onClick={() => deleteContact(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ContactForm({ addContact }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phno, setPhno] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name && email && phno) {
      const newContact = { name, email, phno };
      addContact(newContact);
      setName("");
      setEmail("");
      setPhno("");
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <h2>Contact Form</h2>
        <p>Name:</p>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br />
        <p>Email:</p>
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />
        <p>Phone:</p>
        <input
          type="text"
          value={phno}
          onChange={(e) => setPhno(e.target.value)}
        />
        <button type="submit">Add Contact</button>
      </form>
    </div>
  );
}

function App() {
  const [contacts, setContacts] = useState([]);

  const addContact = (newContact) => {
    setContacts([...contacts, newContact]);
  };

  const handleDeleteContact = (index) => {
    const updatedContacts = [...contacts];
    updatedContacts.splice(index, 1);
    setContacts(updatedContacts);
  };

  return (
    <div>
      <ContactForm addContact={addContact} />
      <ContactList contacts={contacts} deleteContact={handleDeleteContact} />
    </div>
  );
}

const root = document.getElementById("root");
ReactDOM.render(<App />, root);
