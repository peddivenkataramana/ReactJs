 
import React, {useState  } from 'react';
 
 function App(){


const [togg,settog] = useState('light')

  const  handle= () =>{

 settog(togg === 'light'?'dark':'light')
}
const light = {
    backgroundColor: '#ffffff',
    color: '#333333',
  };

  const dark = {
    backgroundColor: '#333333',
    color: '#ffffff',
  };
const buttonStyle = togg ==='light' ? dark : light;

return(
    
    <div style =  {buttonStyle}>
        <button onClick={handle} > 
     toogle
             </button>
          
   
     
    </div>
);



}

 
export default App;