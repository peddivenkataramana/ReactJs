import React from "react";
import ReactDOM from "react-dom";

const img = "https://m.media-amazon.com/images/I/81fOUtK-uOL._SL1500_.jpg";
const title = "Killing the Witches";
const author = "Bill O'Reilly";

const img1 =
  "https://images-na.ssl-images-amazon.com/images/I/814mI0-rkxL._AC_UL450_SR450,300_.jpg";
const title1 = "Elon Musk";
const author1 = "Walter Isaacson";

const img2 = "https://m.media-amazon.com/images/I/81bGKUa1e0L._SL1500_.jpg";
const title2 = "Atomic Habits";
const author2 = "James Clear";

const BookList = (props) => {
  return (
    <div className="container" style={{ marginTop: 100 }}>
      <div className="row justify-content-center">
        <div className="col">
          <div
            className="card"
            style={{ width: 280, height: 380, backgroundColor: "#641E16" }}
          >
            <Book img={img} author={author} title={title} />
          </div>
        </div>
        <div className="col">
          <div
            className="card"
            style={{ width: 280, height: 380, backgroundColor: "#641E16" }}
          >
            <Book img={img1} author={author1} title={title1} />
          </div>
        </div>
        <div className="col">
          <div
            className="card"
            style={{ width: 280, height: 380, backgroundColor: "#641E16" }}
          >
            <Book img={img2} author={author2} title={title2} />
          </div>
        </div>
      </div>
    </div>
  );
};

const Book = (props) => {
  const { img, author, title } = props;

  return (
    <article style={{ textAlign: "center" }}>
      <Image img={img} />
      <div className="card-body" style={{ textAlign: "center" }}>
        <Title title={title} />
        <Author author={author} />
      </div>
    </article>
  );
};

const Image = (props) => (
  <div
    style={{
      width: "100%",
      height: "200px",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <img
      className="card-img-top"
      src={props.img}
      style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }}
      alt=""
    />
  </div>
);

const Title = (props) => (
  <div>
    <h2 style={{ color: "#F2F3F4" }}>{props.title}</h2>
  </div>
);

const Author = (props) => (
  <div style={{ color: "#ECF0F1" }}>{props.author}</div>
);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<BookList />);
