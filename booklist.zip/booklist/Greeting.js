import React from "react";


const Greeting = ({count}) => {
        return(
        <div>
       
<p>'asa',{count}</p>
</div>
    );
}
export default Greeting;