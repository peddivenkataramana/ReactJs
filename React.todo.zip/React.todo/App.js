import React from 'react';
import TaskInput from './TaskInput';
import TaskList from './TaskList';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tasks: [], // Your task list goes here
    };
  }

  // Function to add a task to the task list
  addTask = (taskText) => {
    const newTask = {
      text: taskText,
      // You can add more properties like an ID or completion status here
    };
    this.setState((prevState) => ({
      tasks: [...prevState.tasks, newTask],
    }));
  };

  // Function to delete a task
  deleteTask = (index) => {
    const updatedTasks = [...this.state.tasks];
    updatedTasks.splice(index, 1); // Remove the task at the given index
    this.setState({ tasks: updatedTasks });
  };
  // App.js
onToggleComplete = (index) => {
    const updatedTasks = [...this.state.tasks];
    updatedTasks[index].completed = !updatedTasks[index].completed;
    this.setState({ tasks: updatedTasks });
  };
  

  render() {
    const { tasks } = this.state;

    return (
      <div>
        <h1>To-Do List</h1>
        <TaskInput onAddTask={this.addTask} />
        <TaskList tasks={tasks} onDeleteTask={this.deleteTask} />
       
 
      </div>
    );
  }
}

export default App;
