import React,{Component} from 'react'




class TaskInput extends React.Component {
    
    constructor(props) {
      super(props);
      this.state = {
       task:[]
         
      };
      
    }
  
    addTask =(taskText)=>{
      const newTask ={
          text:taskText,
      };
  
  this.setState((prevState)=>({
      task:[...prevState.task,newTask],
  }));
  
  
    };
  
    // Method to handle input changes
    handleInputChange = (event) => {
      this.setState({ taskText: event.target.value });
      console.log(event.target.value)
  
    };
    handleAddTask = () => {
      this.props.onAddTask(this.state.taskText)
   
     this.setState({taskText:''})
  
  
    };
    
  
    render() {
      return (
        <div>
          <h1>Create Task</h1>
          <input
            type="text"
            placeholder="Enter a new task..."
            value={this.state.taskText}
            onChange={this.handleInputChange}
          />
          <button onClick={this.handleAddTask} >Add Task</button>
         
        </div>
      );
    }
  }

  export default TaskInput