import React from 'react';

const TaskList = ({ tasks, onDeleteTask, onToggleComplete }) => {
  return (
    <div className="task-list">
      <h2>Tasks:</h2>
      <ul>
        {tasks.map((task, index) => (
          <li key={index}>
            <input
      type="checkbox"
      checked={task.completed}
      onChange={() => onToggleComplete(index)} // Call the onToggleComplete function
    />
            <span className={task.completed ? 'completed' : ''}>{task.text}</span>
            <button onClick={() => onDeleteTask(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;
