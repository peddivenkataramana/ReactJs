import React from "react";
import { TiSocialTwitterCircular } from "react-icons/ti";
import { SlSocialFacebook } from "react-icons/sl";
import { SlSocialInstagram } from "react-icons/sl";

import { FaGithub } from "react-icons/fa";

export default function Footter() {
  return (
    <div className="fot">
      <TiSocialTwitterCircular />
      <SlSocialFacebook />
      <SlSocialInstagram />
      <FaGithub />
    </div>
  );
}
