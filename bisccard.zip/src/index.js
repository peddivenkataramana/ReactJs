import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Headerr from "./headerr.js";
import Main from "./mainn.js";
import Footer from "./Footter.js";

function Indexx() {
  return (
    <div className="card">
      <Headerr />
      <Main />
      <Footer />
    </div>
  );
}

ReactDOM.render(<Indexx />, document.getElementById("root"));
