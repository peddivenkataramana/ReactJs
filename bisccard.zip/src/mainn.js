import React from "react";

export default function mainn() {
  return (
    <div className="mainn">
      <h4 className="hh">About</h4>
      <p>
        Ella, a spirited artist with an infectious passion for life, adorned her
        world with vibrant strokes of creativity. Her laughter echoed like a
        melody, weaving through conversations with an unwavering optimism.
        Behind her expressive eyes lay a reservoir of stories, each line on her
        face telling tales of resilience and a journey well-lived.
      </p>
      <h4 className="hh">Interests</h4>
      <p>
        Meet Alex, an avid explorer of both virtual realms and untouched
        landscapes. Their fascination with cutting-edge technology is matched
        only by a love for nature's wonders. From coding intricate programs to
        summiting mountain peaks, Alex's diverse interests form a dynamic
        mosaic, revealing a person driven by curiosity and a thirst for
        adventure.
      </p>
    </div>
  );
}
