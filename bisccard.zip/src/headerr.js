import React from "react";
import { IoIosMail } from "react-icons/io";
import { SlSocialLinkedin } from "react-icons/sl";
import imagee from "./imagee.jpg";
export default function Headerr() {
  return (
    <div className="headd">
      <img src={imagee} />
      <h2>Laura Smith</h2>
      <h3>Frontend Developer</h3>
      <h4>www.LauraSmith.com</h4>
      <div className="btn">
        <button>✉ Email</button>
        <button>
          <SlSocialLinkedin style={{ paddingRight: "3px" }} />
          Linkedin
        </button>
      </div>
    </div>
  );
}
