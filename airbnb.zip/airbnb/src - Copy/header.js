import React from "react";

import { FaAirbnb } from "react-icons/fa6";

export default function header() {
  return (
    <div className="nav">
      <FaAirbnb
        style={{ height: "40px", width: "40px", paddingRight: "4px" }}
      />
      <h1>airbnb</h1>
    </div>
  );
}
