import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Head from "./header.js";
import Headmain from "./headermain.js";
import Base from "./base.js";
function App() {
  return (
    <div>
      <Head />
      <Headmain />
      <Base />
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
