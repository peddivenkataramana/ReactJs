import React from "react";

export default function base() {
  return <div></div>;
}
