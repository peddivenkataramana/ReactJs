import React from "react";
import Imgg from "./Group 77.png";
export default function headermain() {
  return (
    <div className="mainn">
      <img src={Imgg} />
      <h2>Online Experiences</h2>
      <p>
        Join unique interactive activites led by<br></br> one-of-a-kind
        hosts-all without leaving <br />
        home
      </p>
    </div>
  );
}
